import kaboom from "kaboom"

// CONSTANTS
const PLAYER_MOVE_SPEED = 500;
const DOG_SPEED = 550;

// Starts Game

// Width and Height
kaboom({
	width: 540,
	height: 960,
});

//Load Sprites (Import game assets)
loadSprite("bg", "sprites/bg-asset.png");
loadSprite("blueberry", "sprites/blueberry.png");
loadSprite("bone", "sprites/bone.png");
loadSprite("burger", "sprites/burger.png");
loadSprite("cardamon", "sprites/cardamon-a.png");
loadSprite("carrot", "sprites/carrot.png");
loadSprite("donut", "sprites/donut.png");
loadSprite("hand", "sprites/hand-a.png");
loadSprite("hotdog", "sprites/hotdog.png");
loadSprite("orange", "sprites/orange.png");
loadSprite("pizza", "sprites/pizza.png");
loadSprite("strawberry", "sprites/strawberry.png");
loadSprite("heartEmpty", "sprites/heart-empty.png");
loadSprite("heartOne", "sprites/heart-one.png");
loadSprite("heartTwo", "sprites/heart-two.png");
loadSprite("heartThree", "sprites/heart-three.png");

// Load Game Sounds (Import game sounds)
loadSound("music", "sounds/happy.mp3");

// Load Sound Effects
loadSound("chime", "sounds/chime.mp3")
loadSound("btnClick", "sounds/UI_040.wav")
loadSound("munch", "sounds/crunch.ogg")



// Adding Scenes
// - Intro Scene
scene("home", () => {
	add([
		sprite("bg"),
	])

	// Resets the cursor to default cursor
	onUpdate(() => setCursor("default"))

	// Function to create a button
	function addButton(txt, position, next){
		const btn = add([
			rect(240, 80, {radius: 8}),
			//pos(width() / 2, 750),
			pos(position),
			area(),
			scale(1),
			anchor("center"),
			outline(2),
		])
		
		// add a child object that displays the text
		btn.add([
			text(txt),
			anchor("center"),
			color(0, 0, 0),
		])

		btn.onHoverUpdate(() => {
			setCursor("pointer")
			btn.scale = vec2(1.2)
			
		})
	
		btn.onHoverEnd(() => {
			btn.scale = vec2(1)
		})

		btn.onClick(next)
		return btn

	}

	
	// When button is clicked user is taken to 'game'
	addButton("Start Game", vec2(width() / 2, 750), () => go("game"))
	
})

// - Main Game Scene
scene("game", () => {

	const music = play("music", {loop:true});
	

	// Adding UI for Health 
	const ui = add([
		fixed(),
		z(100), // Adds UI on top Z index
	])

	ui.add([
		sprite("heartThree"),
		scale(0.5),
		pos(300, 850),		
	])

	// Add Background
	add([
		sprite("bg", {width: width(), height: height()}) // Gets window width and height demensions for background
	])

	// Add Player (Hand) ------------------
	const player = add([
		// Player components
		sprite("hand"),
		pos(80, 150), // (X , Y)

		// New Polygon to adjust collision area
		area({ shape: new Polygon([vec2(150,150), vec2(150,200), vec2(250,200), vec2(250,150)]) }),
	])

	// Player Movement -------------------
	onKeyDown("right", () => {
		player.move(PLAYER_MOVE_SPEED, 0);
	});
	onKeyDown("left", () => {
		player.move(-PLAYER_MOVE_SPEED, 0);
	});
	onKeyDown("down", () => {
		player.move(0, PLAYER_MOVE_SPEED);
	});
	onKeyDown("up", () => {
		player.move(0, -PLAYER_MOVE_SPEED);
	});


	// Adding CPU (Dog)
	// const dog = add([
	// 	sprite("cardamon"),
	// 	pos(100, 510),
	// 	area(),
	// 	move(LEFT)
	// ])

	const dog = add([
		sprite("cardamon"),
		area({ shape: new Polygon([vec2(75,150), vec2(75,200), vec2(250,200), vec2(250,150)]) }),
		pos(width() / 2, 510),
		"doggo",
		{
			dir: 1,
		},
	])

	dog.onUpdate((p) => {
		dog.move(DOG_SPEED * dog.dir, 0)
		if (dog.dir === 1 && dog.pos.x >= width() - 195) {
			dog.dir = -1
		}
		if (dog.dir === -1 && dog.pos.x <= 1) {
			dog.dir = 1
		}
	})

	
	const food = [
		"blueberry",
		"bone",
		"burger",
		"carrot",
		"donut",
		"hotdog",
		"orange",
		"pizza",
		"strawberry",
	];

	// Select Random Food from 'food' list
	//let randomFood = food[Math.floor(Math.random() * food.length)];
	// console.log(randomFood); // For Testing

	// Falling Foods
	function spawnFoods(){
		 add([
			sprite(food[Math.floor(Math.random() * food.length)]),
			pos(rand(540), 0),
			move(DOWN, rand(240, 900)), // move( DIRECTION, SPEED)
			offscreen({destroy: true}),
			area(),
			// area({ shape: new Polygon([vec2(20,120), vec2(100,120), vec2(100,0), vec2(20,0)]) }),
			"foodObject", // Tag
		])
		wait(rand(0.5, 1), spawnFoods);
		
	}
	spawnFoods();
	

	// Hand Collision with Food
	player.onCollide("foodObject", (foodObject) => {
		destroy(foodObject)
		play("chime")
	})
	player.onCollideUpdate("foodObject", () => {})


	// Dog Eat Count
	let dogCount = 0
	add([
		//text(dogCount),
		{ update() {this.text = dogCount}},
	])

	dog.onCollide("foodObject", (foodObject) => {
		destroy(foodObject)
		play("munch")
		//go("gameover", score)
		dogCount++

		// Dog Count UI
		if(dogCount === 1){
			ui.add([
				sprite("heartTwo"),
				scale(0.5),
				pos(300, 850),
			])
		}

		if(dogCount === 2){
			ui.add([
				sprite("heartOne"),
				scale(0.5),
				pos(300, 850),
			])
		}

		if (dogCount === 3){
			go("gameover", score)
			music.stop()
		}
	})

	// Score
	let score = 0
	const scoreLabel = add([
		text(score),
		pos(40, 30),
		color(0, 0, 0),
	])

	// increment score every frame
	onUpdate(() => {
		score++
		scoreLabel.text = score
	})

	// Adding Food Assets
	// add([
	// 	sprite(randomFood),
	// 	area(),
	// 	pos(200, 10),
	// 	move(DOWN, 240), // move( DIRECTION, SPEED)
	// 	offscreen({destroy: true}),
	// ]);

});

// - End Game Scene ('Score' parameter to see player's final score at end)
scene("gameover", (score) => {
	add([
		sprite("bg")
	])

	add([
		sprite("donut"),
		pos(width() / 2, height() / 2 - 64),
		scale(1),
		anchor("center"),
	])

	// Display Score
	add([
		text(score),
		pos(width() / 2, height() / 2 + 64),
		scale(2),
		anchor("center"),
		color(0, 0, 0),
	])

	// Display Score
	add([
		text("Press Space To Play Again"),
		pos(width() / 2, height() / 2 + 164),
		scale(1),
		anchor("center"),
		color(0, 0, 0),
	])

	// go back to game with space is pressed
	onKeyPress("space", () => go("game"))
});

// 'go' function to start the whole game and switch between scenes
go("home")





